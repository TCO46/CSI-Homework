print("""
      Ta về, mình có nhớ ta
Ta về, ta nhớ những hoa cùng người.
    Rừng xanh hoa chuối đỏ tươi
Đèo cao nắng ánh dao gài thắt lưng.
    Ngày xuân mơ nở trắng rừng
Nhớ người đan nón chuốt từng sợi giang.
     Ve kêu rừng phách đổ vàng
Nhớ cô em gái hái măng một mình
   Rừng thu trăng rọi hoà bình
Nhớ ai tiếng hát ân tình thuỷ chung.
      """)
